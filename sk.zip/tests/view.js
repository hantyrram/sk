const readline = require('readline');

function main(handler){
 
 let i = readline.createInterface({
  input: process.stdin,
  output: process.stdout
 });

 i.on('line',function(line){
  i.close();
  handler(line);
 });

 i.setPrompt('Main >');
 i.prompt();

}


main(function(command){
 console.log(command);
 process.exit();
});

