// const view = require('../view');
const view = require('../view/commandLine');

view.on('error',function(error){
 view.displayError(error); 
});


view.on('message',function(message){
 view.displayMessage(message); 
});

//display this, don't care how you display it, i'll just give you the handler of the input
view.display('request_image',imagePathHandler);


function imagePathHandler(input){

 // try {
  
 //  iDb(input).connect();

 // } catch (error) {
  
 // }
 console.log('You\'ve Entered: ' + input);

 if(input === 'invalidinput'){//sample force error
  view.emit('error',{error:'Invalid Input',message:'You\'ve Entered Incorrect input'});
 }

 if(input === 'message'){//sample force message
  view.emit('message',"The Message");
 }

 view.display('main',mainHandler);

}

function mainHandler(input){
 
  console.log('Processing Input : ' + input);
  
 
 }

//







run - 
    - ask the user for the image Path 
      - on error display error, ask again
    - if no image path provided check the data folder for store.bmp    
    - display the main screen  
      - listen to events

