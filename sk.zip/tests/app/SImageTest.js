const SImage = require('../../app/SImage');

const s = new SImage();

console.log(s.getContent());