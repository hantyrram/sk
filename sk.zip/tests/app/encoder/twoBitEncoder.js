const {encode,decode,twoBitifier}  = require('../../../app/encoder/twoBitEncoder');
const assert = require('assert');

let obj = {
  id: 1,
  label: "myLabel",
  secret: "mySecret"
};

let secret = JSON.stringify(obj);

let bits = twoBitifier(secret);

console.log(`Bits ${bits}`);

let storage = new Buffer.allocUnsafe(secret.length * 4); //need to store secret length * 4 because each byte of secret will be divided by 4

storage.fill('!');

console.log(storage);

let storageWithSecret = encode(bits,storage);

console.log(storageWithSecret.length);

let decoded = decode(storageWithSecret,secret.length,0);

console.log(JSON.parse(decoded));

assert.equal(obj.id,JSON.parse(decoded).id);

