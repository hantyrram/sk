const {binarifySecretData} = require('../steganographer/util');

let secret = 'mysecret';

console.log(binarifySecretData(new Buffer.from(secret)));