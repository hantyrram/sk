// const { performance } = require('perf_hooks');
// performance.mark('A');
// let p = performance.getEntriesByName('A')[0];
// console.log(p);

// function doSomeLongRunningProcess(cb){
//  let idb = require('../app/db/iDb');
//  console.log(idb);
//  let con = new idb();
//  con.on('ready',function(db){
//   console.log(db);
//   cb();
//  });
//  con.connect();
// }

// doSomeLongRunningProcess(() => {
//  performance.mark('B');
//  performance.measure('A to B', 'A', 'B');

//  const measure = performance.getEntriesByName('A to B')[0];
//  console.log(measure.duration);
//  // Prints the number of milliseconds between Mark 'A' and Mark 'B'
// });
// // let fswatcher = fs.watch('docs/docs.txt');
// // fswatcher.on('change',(e,data)=>{
// //  console.log(data);
// // });

// // fs.stat('docs/docs.txt',(e,s)=>{
// //  console.log(e);
// //  console.log(s);
// // });

// // let rs = fs.createReadStream('docs/docs.txt',{autoclose:false});

// // rs.on('open',function(e,d){
// //  console.log('File opened');
// // });

// // rs.on('close',function(e,d){
// //  console.log('File closed');
// // });

// // rs.on('data',function(d){
// //  console.log(d);
// // });


// // fs.access('tests/dummy.txt.txt',fs.constants.R_OK && fs.constants.W_OK,function(err){
// //  console.log(err);
// // });

const readline = require('readline');

const fs = require('fs');



 let i = readline.createInterface({
  input: fs.createReadStream('docs/d.txt'),
  output: process.stdout,
  // crlfDelay: Infinity  
 });

 i.on('line',(line)=>{
  i.write(line);
 });

 