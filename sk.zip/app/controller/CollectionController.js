const Collection = require('../model/Collection');

function CollectionController(db,){

}

CollectionController.prototype.createCollection = function(){
  
}


