const fs = require('fs')

// let b = fs.readFileSync('store.bmp');

// console.log(new Buffer.from(b[0].toString(16) + b[1].toString(16),'hex'));
// console.log((new Buffer.from(b[0].toString(16) + b[1].toString(16),'hex')).toString());
// console.log((new Buffer.from(b[12].toString(16) + b[13].toString(16),'hex')).toString());
// console.log(new Buffer.from(b[0]+b[1],'hex'));

let ws = fs.createWriteStream('created.bmp');

let bb = new Buffer.allocUnsafe(2048);

writeBitmapHeader(bb);
writeDIBHeader(bb);

function writeBitmapHeader(buffer){
 buffer.write('BM',0,2); //identifier
 buffer.writeUInt32BE(2048,2); //size of bmp in bytes
 buffer.writeUInt32BE(30,10);//start of the pixel offset 30
}

function writeBitmapInfoHeader(buffer){
 buffer.writeUInt32BE(40,14); //12 Bytes size of the header
 buffer.writeInt32BE(300,18);//width num of pixel
 buffer.writeInt32BE(300,22);//width num of pixel
 buffer.writeUInt16BE(1,26);//heigh num of pixel
 buffer.writeUInt16BE(8,28); //1
 buffer.writeUInt16BE(24,30); //Number of bits per pixel 24 bit per pixel first parameter, 2nd param is the offset
 buffer.writeUInt16BE(24,30); //Number of bits per pixel 24 bit per pixel first parameter, 2nd param is the offset
 buffer.writeUInt16BE(24,30); //Number of bits per pixel 24 bit per pixel first parameter, 2nd param is the offset
 buffer.writeUInt16BE(24,30); //Number of bits per pixel 24 bit per pixel first parameter, 2nd param is the offset
 buffer.writeUInt16BE(24,30); //Number of bits per pixel 24 bit per pixel first parameter, 2nd param is the offset

}

// console.log(bb);

// ws.write();
i = 30;
while(i!=2020){
 bb.writeUIntBE(Math.floor(Math.random() * 255),i,1);
 i++;
}

// console.log(bb);

ws.write(bb);

