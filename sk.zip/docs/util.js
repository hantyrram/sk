
/**
 *  Converts the secret data into an array which contains 
 *  The pairing of bits of the data padded with 6 0s 
 *  each byte of data is sliced into 4 pairs of bits e.g 11011001 becomes 00000011,00000001,00000010,00000001 
 *  the decimal representation of this data will be OR'd on some of the byte on the image storage
 *  such that e.g. byte on image = 11011110 | 00000011 this will save the secret on 2 least significant bit of the byte on the image
 * 
 * @param {Buffer} secretDataBuffer   - Buffer of the secret data
 * @param {*} arrayToContainThe2BitData - A reference to the array that will contain the 2 bits in string format, the array is not modified
 */
function binarifySecretData(secretDataBuffer,arrayToContainThe2BitData = []){ //default to empty array
 secretDataBuffer.forEach(function(e){ // e is int representaion of the hex on the buffer
   // console.log(Number.parseInt(e.toString()).toString(2));
   //get binary representation of each byte in the buffer = 8 bits
     let bin = Number.parseInt(e.toString()).toString(2);
   //padd with 0 if less than 8, e.g. 1011 = 00001011, in order for us to store the data
     bin = bin.padStart(8,0);
   // slice by 4 such that 11,00,10,11, 
     let arrayOf8Bits = bin.split(""); //[1,1,0,1,1,1..]
     //consolidate the 2 bits to use and put it on the final array of 
     
     arrayOf8Bits.reduce(function(accumulator,currentElement){
       accumulator += currentElement;
       if(accumulator.length === 2){ //if accumalator = '1', next '10' push it to our dataIn2BitsSlice array
       arrayToContainThe2BitData.push(accumulator);
         accumulator = "";
       }
       return accumulator;
     });
     
 
 });
 //padd each  2BitsSlice of the data with 6 0s now we have an array that we can |         
 //actually we don't need this because 2 bits of data should only contain 00,01,10,11 = 0,1,2,3 we just need this numbers     
 //we can directly convert 11 = 3 
 arrayToContainThe2BitData.forEach(function(e,index){// we'll only use this for visual 
  arrayToContainThe2BitData[index] = '000000' + e; // will just convert each value to dec and OR it with the bytes on the storage
 });

 return arrayToContainThe2BitData; // redundancy passed by reference, return the modified array
}


function encode2LeastSignificantBits(targetBuffer, offset ,arrayOfTwoBinaryDataToEncode){

}


module.exports = {
 
 binarifySecretData: binarifySecretData

}