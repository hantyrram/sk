class IExpression{
 interpret(context){}
}

class TerminalExpression extends IExpression{
 
 interpret(context){}
}

